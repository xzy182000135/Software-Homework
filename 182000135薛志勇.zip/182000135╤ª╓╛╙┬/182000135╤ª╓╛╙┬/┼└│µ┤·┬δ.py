import requests
import re
import json
import xlsxwriter
#要爬取的网站
url='https://voice.baidu.com/act/newpneumonia/newpneumonia/?from=osari_aladin_banner'
#进行伪装
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33'
}
#发送请求
response = requests.get(url=url, headers=headers)
#获取数据
html_data = response.text
#解析数据
json_str = re.findall('"component":\[(.*)\],',html_data)[0]
json_dict = json.loads(json_str)
summaryDataIn = json_dict['summaryDataIn']
print(summaryDataIn['unOverseasInputNewAdd']) #新增本土确诊
print(summaryDataIn['asymptomaticLocalRelative']) #新增本土无症状
print(summaryDataIn['specialAdministrativeRegionRelative'])#港澳台新增
caseList = json_dict['caseList']
#保存数据，放入excel文件中
i=1
workbook = xlsxwriter.Workbook('2022.9.19数据统计.xlsx') # 创建一个excel文件
worksheet = workbook.add_worksheet('')  #创建工作表
#编辑excel表格
worksheet.write(0, 0, '省份')
worksheet.write(0, 1, '新增本土')
worksheet.write(0, 2, '新增本土无症状')
worksheet.write(0, 3, '大陆新增本土')
worksheet.write(0, 4, '大陆新增本土无症状')
worksheet.write(0, 5, '港澳台新增')
worksheet.write(1, 3, summaryDataIn['unOverseasInputNewAdd'])
worksheet.write(1, 4, summaryDataIn['asymptomaticLocalRelative'])
worksheet.write(1, 5, summaryDataIn['specialAdministrativeRegionRelative'])
for case in caseList:
    area = case['area']
    nativeRelative = case['nativeRelative']
    asymptomaticLocalRelative = case['asymptomaticLocalRelative']
    print(area, nativeRelative,asymptomaticLocalRelative )
    #通过循环，导入到excel表格中
    worksheet.write(i, 0, area)
    worksheet.write(i, 1, nativeRelative)
    worksheet.write(i, 2, asymptomaticLocalRelative)
    i = i + 1
workbook.close()